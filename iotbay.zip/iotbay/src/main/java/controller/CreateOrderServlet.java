package controller;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.UUID;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.Cart;
import model.CartItem;
import model.User;
import model.dao.DBConnector;
import model.dao.OrderItemManager;
import model.dao.OrderManager;

@WebServlet("/CreateOrderServlet")
public class CreateOrderServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        HttpSession session = request.getSession();
        Cart cart = (Cart) session.getAttribute("cart");
        User user = (User) session.getAttribute("user");

        if (cart == null || cart.getCartItems().isEmpty()) {
            response.sendRedirect("cart.jsp");
            return;
        }

        try {
            DBConnector db = (DBConnector) session.getAttribute("db");
            OrderManager orderManager = new OrderManager(db.openConnection());

            String orderId = UUID.randomUUID().toString();
            String userId = (user != null) ? user.getId() : null;
            boolean isAnonymous = (user == null);
            String anonymousEmail = isAnonymous ? request.getParameter("anonymousEmail") : "";

            Timestamp now = new Timestamp(new Date().getTime());
            double total = cart.calculateTotal();
            String status = "Saved";

            // Save the order
            orderManager.addOrder(orderId, userId, now, total, status, isAnonymous, anonymousEmail);

            // TODO: Save each item in the cart to OrderItem table using OrderItemManager
            OrderItemManager orderItemManager = new OrderItemManager(db.openConnection());

            for (CartItem cartItem : cart.getCartItems()) {
                String itemId = cartItem.getItemId();
                int quantity = cartItem.getQuantity();
                double price = cartItem.getUnitPrice(); // ✅ already stored in CartItem
            
                orderItemManager.addOrderItem(orderId, itemId, quantity, price);
            }


            // Clear cart
            session.setAttribute("cart", new Cart());

            response.sendRedirect("order_confirmation.jsp");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }
}
