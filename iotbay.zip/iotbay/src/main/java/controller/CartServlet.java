package controller;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.Cart;
import model.Item;
import model.Order;
import model.User;
import model.dao.DBConnector;
import model.dao.ItemManager;
import model.dao.OrderManager;

@WebServlet("/CartServlet")
public class CartServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        HttpSession session = request.getSession();
        Cart cart = (Cart) session.getAttribute("cart");
        User user = (User) session.getAttribute("user");

        if (cart == null) {
            cart = new Cart();
            session.setAttribute("cart", cart);
        }

        request.setAttribute("cartItems", cart.getCartItems());
        request.setAttribute("total", cart.calculateTotal());

        if (user != null) {
            try {
                DBConnector db = (DBConnector) session.getAttribute("db");
                OrderManager orderManager = new OrderManager(db.openConnection());
                List<Order> orders = orderManager.getOrdersByCustomer(user.getId()); // or getId()
                request.setAttribute("orders", orders);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        request.getRequestDispatcher("cart.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

        HttpSession session = request.getSession();
        Cart cart = (Cart) session.getAttribute("cart");

        if (cart == null) {
            cart = new Cart();
            session.setAttribute("cart", cart);
        }

        String action = request.getParameter("action");
        String itemIdStr = request.getParameter("itemId");
        String quantityStr = request.getParameter("quantity");

        try {
            String itemId = itemIdStr;
            int quantity = (quantityStr != null) ? Integer.parseInt(quantityStr) : 1;

            ItemManager itemManager = (ItemManager) session.getAttribute("itemManager");

            switch (action) {
                case "add":
                    if (itemManager != null) {
                        Item item = itemManager.findItem(itemId); // FIXED
                        if (item != null) {
                            cart.addItem(item, quantity); // FIXED: use business method
                        }
                    }
                    break;

                case "update":
                    cart.updateItemQuantity(itemId, quantity); // FIXED
                    break;

                case "remove":
                    cart.removeItem(itemId); // FIXED
                    break;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        session.setAttribute("cart", cart);
        response.sendRedirect("CartServlet");
    }
}
